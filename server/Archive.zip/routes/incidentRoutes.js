const express = require('express');
const router = express.Router();
const {
    getIncidents,
    reportIncident,
    reportIncidentWithVideo,
    verifyIncident,
    rejectIncident,
    dispatchIncident,
    respondIncident,
    resolveIncident
} = require('../controllers/incidentController');
const multer = require('multer');

// Configure multer for video file uploads
const upload = multer({ dest: 'uploads/incidents/' });

router.route('/')
    .get(getIncidents);

router.post('/report', reportIncident); // Endpoint for Android App (regular report)

router.post('/report-video', upload.single('video'), reportIncidentWithVideo); // Endpoint for Android App (debug video with multipart/form-data)

router.patch('/:id/verify', verifyIncident);
router.patch('/:id/reject', rejectIncident);
router.post('/:id/dispatch', dispatchIncident);
router.post('/:id/respond', respondIncident);
router.post('/:id/resolve', resolveIncident);

module.exports = router;